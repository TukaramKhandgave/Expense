<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class MemberTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('members', function (Blueprint $table) {
            $table->increments('cust_id');
            $table->string('f_name');
            $table->string('m_name')->nullable();
            $table->string('l_name');
            $table->string('email');
            $table->string('mobile');
            $table->date('birth_date');
            $table->integer('sex');
            $table->integer('cast')->nullable();
            $table->integer('class')->nullable();
            $table->string('address');
            $table->string('qualification')->nullable();
            $table->date('date');
            $table->string('other')->nullable();
            $table->string('image')->nullable();
            $table->tinyInteger('status');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('members');
    }
}
