<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ExpensesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('expenses', function (Blueprint $table) {
            $table->increments('exp_id');
            $table->string('category');
            $table->integer('flag')->comment = '1-expense,2-income';
            $table->string('exp_title')->nullable();
            $table->text('description')->nullable();
            $table->string('price')->nullable();
            $table->string('person_name')->nullable();
            $table->string('contact')->nullable();
            $table->integer('stud_id')->nullable();
            $table->string('student_name')->nullable();
            $table->string('cast')->nullable();
            $table->tinyInteger('fees_type')->nullable()->comment = '1-exam fees,2-tution fees,3-other fees';
            $table->string('other_fees_title')->nullable();
            $table->string('income_amount')->nullable();
            $table->string('total_fees')->nullable();
            $table->string('remain_fees')->nullable();
            $table->date('date');
            $table->tinyInteger('is_deleted');
            $table->tinyInteger('status');
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('expenses');
    }
}
