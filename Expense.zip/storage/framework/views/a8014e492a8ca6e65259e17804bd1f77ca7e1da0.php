
</section>
<script src="<?php echo e(asset('js/jquery-1.10.2.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery-migrate-1.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui-1.10.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.sparkline.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/toggles.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/retina.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.cookies.js')); ?>"></script>


<script src="<?php echo e(asset('js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/raphael-2.1.0.min.js')); ?>"></script>


<script src="<?php echo e(asset('js/chosen.jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<script src="<?php echo e(asset('js/jquery.autogrow-textarea.js')); ?>"></script> 
<script src="<?php echo e(asset('js/bootstrap-fileupload.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/bootstrap-timepicker.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.maskedinput.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.tagsinput.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/jquery.mousewheel.js')); ?>"></script> 
<script src="<?php echo e(asset('js/dropzone.min.js')); ?>"></script> 
<script src="<?php echo e(asset('js/colorpicker.js')); ?>"></script> 
<script src="<?php echo e(asset('js/templateEditor/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/flot/flot.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/flot/flot.resize.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/daterangepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/additional-methods.min.js')); ?>"></script>
<!-- <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script> -->
<!-- <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script> -->
<script type="text/javascript" src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <!-- Bootstrap core JavaScript -->
    
    <!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>

<!-- asset('js/flot/flot.min.js') -->
<!-- asset('js/flot/flot.resize.min.js') -->
<!-- asset('js/dashboard.js') -->

</body>
</html>