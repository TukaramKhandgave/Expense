
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>
 <div class="contentpanel">
    <?php if($errors->any()): ?>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>    
    <form id="form1" class="form-horizontal" name="" method="post" action="<?php echo e(url('/expense/update/'.$result->exp_id)); ?>" enctype="multipart/form-data">
      <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <input type="hidden" name="exp_id" id="exp_id" value="<?php echo e($result->exp_id); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Edit Expense</h4>
        </div>
        <div class="panel-body">
          <div class="form-group">
              <label class="col-sm-3 control-label">Category </label>
              <div class="col-sm-6">
               <select class="form-control" name="category" id="category" >
                  <option value="">Select Category</option>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($cat->cat_id); ?>"<?php if($cat->cat_id == $result->category): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($cat->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            
            <div class="form-group">
              <label class="col-sm-3 control-label">Particulat</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Particulat" id="perticular" name="perticular" class="form-control" value="<?php echo e(old('perticular') ?: $result->exp_title); ?>" >
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Description</label>
              <div class="col-sm-6">
                <textarea class="form-control" placeholder="Description" name="description" id="description" rows="5"><?php echo e(old('description') ?: $result->description); ?></textarea>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Amount</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Amount" id="amount" name="amount" class="form-control" value="<?php echo e(old('amount') ?: $result->price); ?>"/>
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Person Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Person Name" id="person" name="person" class="form-control" value="<?php echo e(old('person') ?: $result->person_name); ?>"/>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Contact</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Contact" id="contact" name="contact" class="form-control" value="<?php echo e(old('contact') ?: $result->contact); ?>"/>
              </div>
            </div>
                       
            <div class="form-group">
              <label class="col-sm-3 control-label">Date</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Date" id="date1" name="date" class="form-control" readonly="" value="<?php echo e(old('date') ?: $result->date); ?>" />
              </div>
            </div> 
           
       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->


  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <script>
  jQuery(document).ready(function(){

  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

    CKEDITOR.replace( 'description' );
  $('#birth_date').datepicker({
            autoclose: true
          })
  /*function getCast(i)
{
  $.ajax({
          type:"POST",
          url:" <?php echo e(url('getCastField')); ?> ",
          data:{id:i,_token:"<?php echo e(Session::token()); ?>" },
          success: function (response)  
          {
             console.log(response);
            $('#cast').val(response.cast);

          },
                      
      });
}*/
  
    </script>