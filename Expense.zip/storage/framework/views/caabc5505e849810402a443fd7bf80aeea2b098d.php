
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>
 <div class="contentpanel">
    <?php if($errors->any()): ?>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>    
    <form id="form1" class="form-horizontal" name="" method="post" action="<?php echo e(url('cast/update/'.$result->cast_id)); ?>" enctype="multipart/form-data">
      <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Edit Sub Cast</h4>
        </div>
        <div class="panel-body">

          <div class="form-group">
              <label class="col-sm-3 control-label">Cast Title </label>
              <div class="col-sm-6">
                <input type="text" placeholder="Cast Title" id="title" name="title" value="<?php echo e(old('title') ?: $result->title); ?>" class="form-control" />
              </div>
            </div>
            
            <div class="form-group">
              <label class="col-sm-3 control-label">Fees</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Fees" id="fees" name="fees" value="<?php echo e(old('fees') ?: $result->fees); ?>" class="form-control" />
              </div>
            </div> 
            
                      
       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->


  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <script>
  jQuery(document).ready(function(){

  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

      CKEDITOR.replace( 'other' );
      CKEDITOR.replace( 'address' );
  $('#date_of_birth,#join_date').datepicker({
            autoclose: true
          })
  
    </script>