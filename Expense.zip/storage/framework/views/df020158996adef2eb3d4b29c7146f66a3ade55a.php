<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>

      <div class="contentpanel">
          <?php if($errors->any()): ?>
           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          <form id="form1" class="form-horizontal" name="frm_submit_cms" method="post" action="<?php echo e(url('post_password')); ?>" >
            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
              <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">Change Password</h4>
              </div>
              <div class="panel-body">
              <?php if(Session::has('success_msg')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
                    <?php endif; ?>
                <!-- <div class="form-group">
                  <label class="col-sm-4 control-label">Old Password:<span class="asterisk">*</span></label>
                  <div class="col-sm-8">
                    <input type="password" id="old_password" name="old_password" class="form-control" required="" />
                  </div>
                </div> -->
                
                <div class="form-group">
                  <label class="col-sm-4 control-label">New Password:<span class="asterisk">*</span></label>
                  <div class="col-sm-8">
                    <input type="password" id="new_password" name="new_password" class="form-control" required="" />
                  </div>
                </div>
                 <div class="form-group">
                  <label class="col-sm-4 control-label">Confirm Password:<span class="asterisk">*</span></label>
                  <div class="col-sm-8">
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required="" />
                  </div>
                </div>
              </div><!-- panel-body -->
              <div class="panel-footer">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary pull-left"> Back</a>
                <button class="btn btn-primary pull-right">Submit</button>
              </div><!-- panel-footer -->
            </div><!-- panel-default -->
          </form>
         
    </div>
    
  </div><!-- mainpanel -->

 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>