<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="pageheader">

    </div>
 <div class="contentpanel">

          <form id="form1" class="form-horizontal form-bordered" name="frm_submit_word" method="post" action="<?php echo e(url('classes/insert')); ?> " enctype="multipart/form-data" >
            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Add a new class</h4>
        </div>
        <?php if($errors->any()): ?>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="alert alert-danger"><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="panel-body panel-body-nopadding">


          <div class="form-group">
              <label class="col-sm-3 control-label">Class Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Class Name" id="class_name" name="class_name" value="<?php echo e(old('class_name')); ?>" class="form-control" />
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Cemester Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Cemester Name" id="cem_name" name="cem_name" value="<?php echo e(old('cem_name')); ?>" class="form-control" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Year</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Year" id="year" name="year" value="<?php echo e(old('year')); ?>" class="form-control" />
              </div>
            </div> 


       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
    <script>
  jQuery(document).ready(function(){

  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

      CKEDITOR.replace( 'other' );
      CKEDITOR.replace( 'address' );

       function insertText(obj) {
                newtext = obj.value;
                console.log(newtext);
                CKEDITOR.instances['content'].insertText(newtext);

            }
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                  $("#preview_img").css("display", "block");
                    $('#preview').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }  
                  
          $('#date_of_birth,#join_date').datepicker({
            autoclose: true
          })

  
    </script>