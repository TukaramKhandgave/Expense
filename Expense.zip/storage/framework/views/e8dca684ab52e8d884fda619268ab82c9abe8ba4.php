<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
   <!-- <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/png"> -->
  <!-- <link rel="shortcut icon" href="public/images/favicon.png" type="image/png"> -->

  <title>Expense Manage</title>
<link href="<?php echo e(asset('css/style.default.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery.datatables.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/daterangepicker.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
<style type="text/css"></style>
</head>

<body>
    
<!-- Preloader -->
<div id="preloader">
    <div id="status"><i class="fa fa-spinner fa-spin"></i></div>
</div>

<section>
  
  <div class="leftpanel">
    
    <div class="logopanel">
        <h1><span></span><a href="<?php echo e(url('/')); ?>">Expense Manage </a><span></span></h1>
    </div><!-- logopanel -->
        
    <div class="leftpanelinner">    
        
        <!-- This is only visible to small devices -->
        <div class="visible-xs hidden-sm hidden-md hidden-lg">   
            <div class="media userlogged">
                <img alt="" src="images/photos/loggeduser.png" class="media-object">
                <div class="media-body">
                 <?php if(Session::has('USER_ID')): ?>
                    <h4><?php echo e(Session::get('NAME')); ?></h4>
                    <span>"Life is so..."</span>
                    <?php endif; ?>
                </div>
            </div>
          
            <h5 class="sidebartitle actitle">Account</h5>
            <ul class="nav nav-pills nav-stacked nav-bracket mb30">
              <li><a href="<?php echo e(url('/profile')); ?>"><i class="fa fa-user"></i> <span>Profile</span></a></li>
              <li><a href="<?php echo e(url('logout')); ?>"><i class="fa fa-sign-out"></i> <span>Sign Out</span></a></li>
            </ul>
        </div>
      
      <!-- <h5 class="sidebartitle">Navigation</h5> -->
     
      <ul class="nav nav-pills nav-stacked nav-bracket">
        
        <li class="<?php if(Request::segment(1) == 'admin'): ?> active <?php endif; ?>"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
        <li class="nav-parent nav-stacked nav-bracket <?php if(Request::segment(1) == 'category' || Request::segment(1) == 'cast'|| Request::segment(1) == 'classes'): ?> active <?php endif; ?> "><a href="#"><i class="fa fa-cogs"></i> <span>Master Data</span></a>
        <ul class="children">
          <li class="<?php if(Request::segment(1) == 'category'): ?> active <?php endif; ?>"><a href="<?php echo e(url('category')); ?>"><i class="fa fa-caret-right"></i> Category </a></li>
          <li class="<?php if(Request::segment(1) == 'cast'): ?> active <?php endif; ?>" ><a href="<?php echo e(url('cast')); ?>"><i class="fa fa-caret-right"></i> Cast</a></li>
          <li class="<?php if(Request::segment(1) == 'classes'): ?> active <?php endif; ?>" ><a href="<?php echo e(url('classes')); ?>"><i class="fa fa-caret-right"></i> Classes</a></li>
        </ul> 
        
        <li class="<?php if(Request::segment(1) == '/member'): ?> active <?php endif; ?> "><a href="<?php echo e(url('/member')); ?>"><i class="fa fa-users"></i> <span>Student Management</span></a></li>
        <li class="<?php if(Request::segment(1) == '/fees'): ?> active <?php endif; ?> "><a href="<?php echo e(url('/fees')); ?>"><i class="fa fa-money"></i> <span>Income Management</span></a></li>
        <li class="<?php if(Request::segment(1) == '/expense'): ?> active <?php endif; ?> "><a href="<?php echo e(url('/expense')); ?>"><i class="fa fa-money"></i> <span>Expense Management</span></a></li>
       <!--  <li class="<?php if(Request::segment(1) == '/staff_sal'): ?> active <?php endif; ?> "><a href="<?php echo e(url('/staff_sal')); ?>"><i class="fa fa-users"></i> <span>Staff Salary Management</span></a></li>
       <li class="nav-parent nav-stacked nav-bracket <?php if(Request::segment(1) == 'book' || Request::segment(1) == 'book_issue'): ?> active <?php endif; ?> "><a href="#"><i class="fa fa-cogs"></i> <span>Library Management</span></a> -->
        <ul class="children">
          <li class="<?php if(Request::segment(1) == 'book'): ?> active <?php endif; ?>"><a href="<?php echo e(url('book')); ?>"><i class="fa fa-caret-right"></i> Book </a></li>
          <li class="<?php if(Request::segment(1) == 'book_issue'): ?> active <?php endif; ?>" ><a href="<?php echo e(url('book_issue')); ?>"><i class="fa fa-caret-right"></i> Book Issue</a></li>
         </ul>
      </li>
      </ul>
      
     

      <!-- infosummary -->
       
    </div><!-- leftpanelinner -->
  </div><!-- leftpanel -->
  <div class="mainpanel">

    <!-- header start -->
    <div class="headerbar">
      
      <a class="menutoggle"><i class="fa fa-bars"></i></a>
      

      <div class="header-right">
        <ul class="headermenu">
         <li>
            <div class="btn-group">
              <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                <!-- <img src="images/photos/loggeduser.png" alt="" /> -->
               <?php echo e(Auth::user()->name); ?>

                <span class="caret"></span>
              </button>
              <ul class="dropdown-menu dropdown-menu-usermenu pull-right">
                <li><a href="<?php echo e(url('/profile')); ?>"><i class="glyphicon glyphicon-user"></i> My Profile</a></li>
                <li><a href="<?php echo e(url('/change_password')); ?>"><i class="glyphicon glyphicon-cog"></i>Change Password</a></li>
                <li><a href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="glyphicon glyphicon-log-out"></i> Log Out</a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div><!-- header-right -->
      
    </div><!-- headerbar -->
    
    