<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
    <div class="pageheader">
      <div class="container-fluid">
         <div class="row">
          <div class="col-md-4">
            <h4 class="panel-title">Cast Listing</h4>
          </div>
            <div class="col-md-8"></div>
            <a href="<?php echo e(('/cast/add')); ?>" class="btn btn-primary btn-md pull-right">Add New</a>
          </div>         
      </div>
    </div>
    
    <div class="contentpanel">
     
      <div class="panel panel-default">
        <div class="panel-body">
           <?php if(Session::has('success_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
      
          <div class="table-responsive">
             
          <table class="table  tableid" id="table2">
              <thead>
              <tr>
               <th>#Sr.No.</th>
               <th>Title</th>
               <th>Fees</th>
               <th>Action</th>
              </tr>
            </thead>
            <tbody id="tbody_tableid">
              <?php
              $i=1;
              ?>
              <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($row->title); ?></td>
                <td><?php echo e($row->fees); ?></td>
                                
                <td>
                    <a href="<?php echo e(url('cast/edit/' . base64_encode($row->cast_id))); ?>" class=""><i class="fa fa-pencil" aria-hidden="true" title="Edit template"></i></a>&nbsp;&nbsp;
                    <a href="<?php echo e(url('cast/delete/'. $row->cast_id)); ?>" class="" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash-o" aria-hidden="true" title="Delete Customer"></i></a>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </tbody>
          </table>

          </div><!-- table-responsive -->
        </div><!-- col-md-6 -->

        
      </div>
        
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
  jQuery(document).ready(function() {
    
    jQuery('#table1').dataTable();
    
    jQuery('#table2').dataTable({
      "sPaginationType": "full_numbers"
    });


    // Chosen Select
    jQuery("select").chosen({
      'min-width': '100px',
      'white-space': 'nowrap',
      disable_search_threshold: 10
    });
    
    // Delete row in a table
    jQuery('.delete-row').click(function(){
      var c = confirm("Continue delete?");
      if(c)
        jQuery(this).closest('tr').fadeOut(function(){
          jQuery(this).remove();
        });
        
        return false;
    });
    
    // Show aciton upon row hover
    jQuery('.table-hidaction tbody tr').hover(function(){
      jQuery(this).find('.table-action-hide a').animate({opacity: 1});
    },function(){
      jQuery(this).find('.table-action-hide a').animate({opacity: 0});
    });
  
  
  });

</script>

<script type="text/javascript">
  
function filter_call(i)
      {
         
            $.ajax({
              type:"POST",
              url:" <?php echo e(url('customers/filterCall')); ?> ",
              data:{id:i,_token:"<?php echo e(Session::token()); ?>" },
              success: function (response) 
              {
                 
                   console.log(response);
        
                    var arr=response;
                    var len=arr.length;
                    var str='';
          
                    for(var i=0;i<len;i++)
                {
                  var j = i+1;
                  var user_id = arr[i].tr_id;
                  var encoded_value = btoa(user_id);
                  var redirect_url_details = '<?php echo url('customers/details/.')?>'  +encoded_value ;

                  var redirect_url_edit = '<?php echo url('customers/edit/.')?>'  +encoded_value ;
                  var redirect_url_delete = '<?php echo url('customers/delete/.')?>' +encoded_value;
                  var redirect_url_status = '<?php echo url('trainers/status/.')?>' +encoded_value;
                  var status = arr[i].status == 1 ? 'Active' : 'In-Active';
                 str=str+"<tr><td>"+arr[i].cust_name+"</td><td>"+arr[i].cust_email+"</td><td>"+arr[i].cust_mobile+"</td><td>"+arr[i].address+"</td><td><a href="+redirect_url_status+" class=''>"+status+"</td><td><a href="+redirect_url_details+" class=''><i class='fa fa-eye' aria-hidden='true' title='Click to view details'></i></a>&nbsp;&nbsp;<a href="+redirect_url_edit+" class=''> <i class='fa fa-pencil' aria-hidden='true' title='Edit template'></i></a>&nbsp;&nbsp;<a href="+redirect_url_delete+" class='' onclick='return confirm('Are you sure to delete?')><i class='fa fa-trash-o' aria-hidden='true' title='Delete Customer'></i></a></td></tr>";
              
               }

            var table = $('.tableid').DataTable();
            table.destroy();
            $("#tbody_tableid").html("");
            $("#tbody_tableid").append(str);
            var table = $('.tableid').DataTable( {
            responsive: true,
            paging: true,
            searching: true,
            "sPaginationType": "full_numbers"
            } );
            jQuery("select").chosen({
              'min-width': '100px',
              'white-space': 'nowrap',
              disable_search_threshold: 10
            });


              },
              error: function (xhr) {
              }
                
              
          });



        

          
      }

</script>