    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <div class="pageheader">
      <h2><i class="fa fa-home"></i> Dashboard</h2>
      <div class="breadcrumb-wrapper">
        <span class="label">You are here:</span>
        <ol class="breadcrumb">
          <!-- <li><a href="index-2.html">Bracket</a></li> -->
          <li class="active">Dashboard</li>
        </ol>
      </div>
    </div>
    <div class="contentpanel">
       
      <div class="row">
        <?php if(Session::has('success_msg')): ?>
          <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>
        <!DOCTYPE HTML>
<html>
<head>
<script>
 

window.onload = function () {



}
</script>
</head>
<body>
  <?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
      <?php echo e(\Session::get('error')); ?>

    </div>
  <?php endif; ?>
<!-- <div id="chartContainer" style="height: 300px; width: 100%;"></div> -->
<!-- <canvas id="myChart"></canvas> -->

 
      <div class="row">
        
        <div class="col-sm-6 col-md-4">
          <div class="panel panel-success panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                    <i class="fa fa-users"></i>
                   
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Total Students</small>
                    <h1><?php echo e($result); ?></h1>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                <!-- <div class="row">
                  <div class="col-xs-6">
                    <small class="stat-label">Last Week</small>
                  </div>
                  
                  <div class="col-xs-6">
                  <small class="stat-label"><i class="fa  fa-arrow-circle-right"></i></small>
                  </div>
                </div> -->
               
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-4">
          <div class="panel panel-danger panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                   <i class="fa fa-money"></i>
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Total Expenses records</small>
                    <h1><?php echo e($result1); ?></h1>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                
                                 
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
        
        <div class="col-sm-6 col-md-4">
          <div class="panel panel-primary panel-stat">
            <div class="panel-heading">
              
              <div class="stat">
                <div class="row">
                  <div class="col-xs-4">
                   <i class="fa fa-money"></i>
                  </div>
                  <div class="col-xs-8">
                    <small class="stat-label">Total Income records</small>
                    <h1><?php echo e($result2); ?></h1>
                  </div>
                </div><!-- row -->
                
                <div class="mb15"></div>
                                  
              </div><!-- stat -->
              
            </div><!-- panel-heading -->
          </div><!-- panel -->
        </div><!-- col-sm-6 -->
       
      </div><!-- row -->

</body>
</html>
      </div><!-- row -->
     
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script type="text/javascript">
    jQuery(document).ready(function() {
  getChart();
 });

 function getChart()
      { 

            var values= [''];
            var label_value= [''];

          $.ajax({
              type:"POST",
              url:" <?php echo e(url('dashboard')); ?> ",
              data:{_token:"<?php echo e(Session::token()); ?>" },
              success: function (response) { console.log(response);
             
              var ctx = document.getElementById("myChart").getContext('2d');

                var arr=response;
                var len=arr.length;
                for(var i=0;i<len;i++)
                { 

                  var d = new Date(arr[i].date_time);
                    month = d.getMonth() + 1;
                    day = d.getDate();
                    year = d.getFullYear();
                    var date = day+"-"+month+"-"+year;
                 
                    values.push(arr[i].user_input);
                    label_value.push(date);
               }

    //var values = [12, 19, 3, 5, 2, 35, 2, 35, 2, 3,5];
    //var label_value = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: label_value,
                datasets: [{
                    label: '# of Votes',
                    data: values,
                    
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });

              },
   
          });
      }
  </script>