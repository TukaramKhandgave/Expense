
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <!-- <link rel="shortcut icon" href="images/favicon.png" type="image/png"> -->

  <title>Manage</title>

  <link href="<?php echo e(asset('css/style.default.css')); ?>" rel="stylesheet">
</head>

<body class="signin">

<!-- Preloader -->
<div id="preloader">
    <div id="status"><i class="fa fa-spinner fa-spin"></i></div>
</div>

<section>
  
    <div class="signinpanel">
        
        <div class="row">
            
            <div class="col-md-4">
               
            </div><!-- col-sm-4 -->
            
            <div class="col-md-5">
              <?php if(Session::has('success_msg')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
                <?php endif; ?>
            <div class="card">
                <div class="card-header"><?php echo e(__('Admin Login')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <h4 class="nomargin">Sign In</h4>
                            <p class="mt5 mb20">Login to access your account.</p>
                                <input id="email" type="email" class="form-control uname<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                             <a href="<?php echo e(route('register')); ?>" class="pull-right"><small>Not a member? Sign Up</small></a> 
                            
                            <button type="submit" class="btn btn-success btn-block">Sign In</button>

                    </form>
                    <!-- <div class="col-md-8">
                       <a href="<?php echo e(('redirect')); ?>" class="btn btn-primary btn-md pull-right">Sign up with Facebook</a>
                    </div> -->
                </div>
            </div>
        
            </div><!-- col-sm-5 -->
            
        </div><!-- row -->
        
        <div class="signup-footer">

        </div>
        
    </div><!-- signin -->
  
</section>


<script src="<?php echo e(asset('js/jquery-1.10.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-migrate-1.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/retina.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

</body>

</html>

