
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>
 <div class="contentpanel">
    <?php if($errors->any()): ?>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>    
    <form id="form1" class="form-horizontal" name="" method="post" action="<?php echo e(url('category/update/'.$result->cat_id)); ?>" enctype="multipart/form-data">
      <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Edit Category</h4>
        </div>
        <div class="panel-body">

          <div class="form-group">
              <label class="col-sm-3 control-label">Category Type</label>
              <div class="col-sm-3">
                <input type="radio" name="category_type" value="1"<?php if($result->cat_type=='1'): ?> <?php echo e('checked'); ?> <?php endif; ?>> Expense [-]<br>
              </div>
              <div class="col-sm-3">
                <input type="radio" name="category_type" value="2" <?php if($result->cat_type=='2'): ?> <?php echo e('checked'); ?> <?php endif; ?> > Income[+]<br>
              </div>
            </div>
            
            <div class="form-group">
              <label class="col-sm-3 control-label">Category Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Category Name" id="category_name" name="category_name" value="<?php echo e(old('category_name') ?: $result->category_name); ?>" class="form-control" />
              </div>
            </div> 
            
       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->


  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <script>
  jQuery(document).ready(function(){

  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

      CKEDITOR.replace( 'other' );
      CKEDITOR.replace( 'address' );
  $('#date_of_birth,#join_date').datepicker({
            autoclose: true
          })
  
    </script>