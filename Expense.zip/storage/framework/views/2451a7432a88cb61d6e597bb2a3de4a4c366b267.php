
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>
 <div class="contentpanel">
    <?php if($errors->any()): ?>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>    
    <form id="form1" class="form-horizontal" name="" method="post" action="<?php echo e(url('classes/update/'.$result->class_id)); ?>" enctype="multipart/form-data">
      <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Edit Class</h4>
        </div>
        <div class="panel-body">
            
            <div class="form-group">
              <label class="col-sm-3 control-label">Class Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Class Name" id="class_name" name="class_name" value="<?php echo e(old('class_name') ?: $result->class_name); ?>" class="form-control" />
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Cemester Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Cemester Name" id="cem_name" name="cem_name" value="<?php echo e(old('cem_name') ?: $result->cem_name); ?>" class="form-control" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Year</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Year" id="year" name="year" value="<?php echo e(old('year') ?: $result->year); ?>" class="form-control" />
              </div>
            </div> 
            

       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->


  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <script>
  jQuery(document).ready(function(){

  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

      CKEDITOR.replace( 'other' );
      CKEDITOR.replace( 'address' );
  $('#date_of_birth,#join_date').datepicker({
            autoclose: true
          })
  
    </script>