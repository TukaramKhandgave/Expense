
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>
 <div class="contentpanel">
    <?php if($errors->any()): ?>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>    
    <form id="form1" class="form-horizontal" name="" method="post" action="<?php echo e(url('/fees/update/'.$result->exp_id)); ?>" enctype="multipart/form-data">
      <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <input type="hidden" name="exp_id" id="exp_id" value="<?php echo e($result->exp_id); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Edit Income</h4>
        </div>
        <div class="panel-body">
         
            <div class="form-group">
              <label class="col-sm-3 control-label">Category <span class="asterisk">*</span></label>
              <div class="col-sm-6">
               <select class="form-control" name="category" id="category" onchange="changeCat(this.value)" >
                  <option value="">Select Category</option>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($cat->cat_id); ?>"<?php if($cat->cat_id == $result->category): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($cat->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <input type="hidden" name="cat_type" id="cat_type" value="<?php echo e($result->cat_type); ?>">
            </div>
          <div id="fees_div" style="display: none;">
            <div class="form-group">
              <label class="col-sm-3 control-label">Student Name <span class="asterisk">*</span></label>
              <div class="col-sm-6">
               <select class="form-control" name="student_name" id="student_name" onchange="getCast(this.value);">
                    <option value="">Select Student</option>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($member->cust_id); ?>, <?php echo e($member->f_name); ?> <?php echo e($member->m_name); ?> <?php echo e($member->l_name); ?>"<?php if($member->cust_id == $result->stud_id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($member->f_name); ?> <?php echo e($member->l_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div> 
            <input type="hidden" name="full_name" id="full_name" value="<?php echo e(old('full_name') ?: $result->student_name); ?>">
            <input type="hidden" name="stud_id" id="stud_id" value="<?php echo e(old('stud_id') ?: $result->stud_id); ?>">
            <div class="form-group">
              <label class="col-sm-3 control-label">Cast</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Cast" id="cast" name="cast" class="form-control" value="<?php echo e(old('cast') ?: $result->cast); ?>" readonly="readonly"  value="" >
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Fees Type <span class="asterisk">*</span></label>
              <div class="col-sm-2">
                <input type="radio" name="fees_type" value="1" checked onclick="showOther(this.value)"<?php if($result->fees_type == 1): ?> checked="checked" <?php endif; ?>> Exam Fees<br>
              </div>
              <div class="col-sm-2">
                <input type="radio" name="fees_type" value="2" onclick="showOther(this.value)"<?php if($result->fees_type == 2): ?> checked="checked" <?php endif; ?>> Tution Fees<br>
              </div>
              <div class="col-sm-2">
                <input type="radio" name="fees_type" value="3" onclick="showOther(this.value)"<?php if($result->fees_type == 3): ?> checked="checked" <?php endif; ?> > Other Fees<br>
              </div>
            </div>
             <?php if($result->fees_type == 3): ?>
            <div id="others" style="display: show;">
              <div class="form-group">
               <label class="col-sm-3 control-label">Other Fees Title <span class="asterisk">*</span></label>
                <div class="col-sm-6">
                  <input type="text" id="other_title" placeholder="Title" name="other_title" value="<?php echo e(old('other_title') ?: $result->other_fees_title); ?>" class="form-control" />
                </div>
              </div>
              <div class="form-group">
               <label class="col-sm-3 control-label">Fees <span class="asterisk">*</span></label>
                <div class="col-sm-6">
                  <input type="text" id="other_fees" placeholder="Fees" name="other_fees" value="<?php echo e(old('other_fees') ?: $result->income_amount); ?>" class="form-control" />
                </div>
              </div> 
            </div>
            <?php else: ?>
            <div id="others" style="display: none;">
              <div class="form-group">
               <label class="col-sm-3 control-label">Other Fees Title <span class="asterisk">*</span></label>
                <div class="col-sm-6">
                  <input type="text" id="other_title" placeholder="Title" name="other_title" value="<?php echo e(old('other_title') ?: $result->other_title); ?>" class="form-control" />
                </div>
              </div>
              <div class="form-group">
               <label class="col-sm-3 control-label">Fees <span class="asterisk">*</span></label>
                <div class="col-sm-6">
                  <input type="text" id="other_fees" placeholder="Fees" name="other_fees" value="<?php echo e(old('other_fees') ?: $result->other_fees); ?>" class="form-control" />
                </div>
              </div> 
            </div>
            <?php endif; ?>
            <?php if($result->fees_type == 1): ?>
            <div class="form-group" id="exam_fees" style="display: show;">
              <label class="col-sm-3 control-label">Exam Fees <span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Exam Fees" id="exam_fee" name="exam_fee" class="form-control" value="<?php echo e(old('exam_fee') ?: $result->income_amount); ?>"/>
              </div>
            </div>
            <?php else: ?>
            <div class="form-group" id="exam_fees" style="display: none;">
              <label class="col-sm-3 control-label">Exam Fees <span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Exam Fees" id="exam_fee" name="exam_fee" class="form-control" value="<?php echo e(old('exam_fee') ?: $result->income_amount); ?>"/>
              </div>
            </div>
            <?php endif; ?>
            <?php if($result->fees_type == 2): ?>
            <div id="tution_fees_div" style="display: show;">
            <div class="form-group">
              <label class="col-sm-3 control-label">Total Fee</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Total Fee" id="total_fee" name="total_fee" class="form-control" value="<?php echo e(old('total_fee') ?: $result->total_fees); ?>" readonly="" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Paid Fee <span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Paid Fee" id="paid_fee" name="paid_fee" class="form-control" value="<?php echo e(old('paid_fee') ?: $result->income_amount); ?>" onchange="calculate_fees(this.value)" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Remain Fee</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Remain Fee" id="remain_fee" name="remain_fee" class="form-control" value="<?php echo e(old('remain_fee') ?: $result->remain_fees); ?>" readonly="" />
              </div>
            </div>
          </div>
          <?php else: ?>
          <div id="tution_fees_div" style="display: none;">
            <div class="form-group">
              <label class="col-sm-3 control-label">Total Fee</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Total Fee" id="total_fee" name="total_fee" class="form-control" value="<?php echo e(old('total_fee') ?: $result->total_fees); ?>" readonly="" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Paid Fee <span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Paid Fee" id="paid_fee" name="paid_fee" class="form-control" value="<?php echo e(old('paid_fee') ?: $result->income_amount); ?>" onchange="calculate_fees(this.value)" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Remain Fee</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Remain Fee" id="remain_fee" name="remain_fee" class="form-control" value="<?php echo e(old('remain_fee') ?: $result->remain_fees); ?>" readonly="" />
              </div>
            </div>
          </div>
          <?php endif; ?>
          </div>
          <div id="non_fees_div" style="display: none;">
            <div class="form-group">
              <label class="col-sm-3 control-label">Perticular<span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Perticular" id="perticular" name="perticular" class="form-control" value="<?php echo e(old('perticular') ?: $result->exp_title); ?>" >
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Description</label>
              <div class="col-sm-6">
                <textarea class="form-control" placeholder="Description" name="description" id="description" rows="5"><?php echo e(old('description') ?: $result->description); ?></textarea>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Amount <span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Amount" id="amount" name="amount" class="form-control" value="<?php echo e(old('amount') ?: $result->income_amount); ?>"/>
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Person Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Person Name" id="person" name="person" class="form-control" value="<?php echo e(old('person') ?: $result->person_name); ?>"/>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Contact</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Contact" id="contact" name="contact" class="form-control" value="<?php echo e(old('contact') ?: $result->contact); ?>"/>
              </div>
            </div>
          </div><br>
            <div class="form-group">
              <label class="col-sm-3 control-label">Date <span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Date" id="date1" name="date" class="form-control" readonly="" value="<?php echo e(old('date') ?: $result->date); ?>" />
              </div>
            </div>  

       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->


  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <script>
  jQuery(document).ready(function(){
    incCategory();
  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

      CKEDITOR.replace( 'description' );
  $('#date1').datepicker({
            autoclose: true
          })
  function incCategory()
  {
     var cat = $('#cat_type').val();
     
     if(cat == 2){
        document.getElementById('fees_div').style.display ='block';
        document.getElementById('non_fees_div').style.display ='none';
      }else{
        document.getElementById('non_fees_div').style.display ='block';
        document.getElementById('fees_div').style.display ='none';
      }

  }

  function getCast(i) 
{  
  var strArray = i.split(","); 
  $.ajax({
          type:"POST",
          url:" <?php echo e(url('getCastField')); ?> ",
          data:{id:strArray[0],_token:"<?php echo e(Session::token()); ?>" },
          success: function (response)  
          { 
             console.log(response);
            $('#cast').val(response.title);
            $('#total_fee').val(response.fees);
            $('#full_name').val(strArray[1]);
            $('#stud_id').val(strArray[0]);

          },
                      
      });
}

function showOther(i){
    if(i==3){
        document.getElementById('others').style.display ='block';
        document.getElementById('exam_fees').style.display ='none';
        document.getElementById('tution_fees_div').style.display ='none';
      }else if(i==2){
        document.getElementById('others').style.display ='none';
        document.getElementById('exam_fees').style.display ='none';
        document.getElementById('tution_fees_div').style.display ='block';
      }else{
        document.getElementById('exam_fees').style.display ='block';
        document.getElementById('others').style.display ='none';
        document.getElementById('tution_fees_div').style.display ='none';
      }
    }
    function calculate_fees(f){
        var total_fees = $('#total_fee').val();
        var remain_fees = total_fees - f ; 
        $('#remain_fee').val(remain_fees);
    }
     function changeCat(c){ 
      $.ajax({
          type:"POST",
          url:" <?php echo e(url('getCatType')); ?> ",
          data:{cat_id:c,_token:"<?php echo e(Session::token()); ?>" },
          success: function (response)  
          { 
             //console.log(response);
            $('#cat_type').val(response.cat_type);
             if(response.cat_type==2){
                 document.getElementById('fees_div').style.display ='block';
                 document.getElementById('non_fees_div').style.display ='none';
              }else{
                 document.getElementById('fees_div').style.display ='none';
                 document.getElementById('non_fees_div').style.display ='block';
              }
          },
                      
      });
      
        
    }
    </script>