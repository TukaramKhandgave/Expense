<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
    <div class="pageheader">
      <div class="container-fluid">
         <div class="row">
          <div class="col-md-4">
            <h4 class="panel-title">Student Listing</h4>
          </div>
            <div class="col-md-8"></div>
            <a href="<?php echo e(('/member/add')); ?>" class="btn btn-primary btn-md pull-right">Add New</a>
          </div>         
      </div>
    </div>
    
    <div class="contentpanel">
     
      <div class="panel panel-default">
        <div class="panel-body">
           <?php if(Session::has('success_msg')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></div>
        <?php endif; ?>

        <div class="row"> 
           <form id="" class="" name="frm_submit_word" method="post" action="<?php echo e(url('member/downloadExcel')); ?>" enctype="multipart/form-data" >
               <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
              <div class="form-group">
                <div class="col-sm-3">
                  <input type="text" placeholder="Date" id="datefilter" name="datefilter" value="<?php echo e(old('datefilter')); ?>" class="form-control" readonly="" />
                </div>
              
                <div class="col-sm-3">
                  <button type="submit" class="btn btn-primary">Download report</button>
                
                </div>
              </div>
            </form>
         <!--  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
           <div class="dropdown show" style="margin-right: 5px;">
              <a class="btn btn-primary dropdown-toggle" href="<?php echo e(url('member/downloadExcel')); ?>" role="button" id="dropdownMenuLink" >
                Download report
              </a>

            </div>
          </div> -->
        </div>
        <br>
      
          <div class="table-responsive">
             
          <table class="table  tableid" id="table2">
              <thead>
              <tr>
               <th>#Sr.No.</th>
              <!--  <th>Photo</th> -->
               <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
               <!--  <th>Status</th> -->
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="tbody_tableid">
              <?php
              $i=1;
              ?>
              <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($i++); ?></td>
                <!-- <td>
                  <?php if($row->image): ?>
                  <img style="height:50px; width:60px" class="d-block w-100" src="<?php echo e(asset('profile_images/'.$row->image)); ?>"></img>
                  <?php else: ?>
                  <img style="height:50px; width:60px" class="d-block w-100" src="<?php echo e(asset('news_images/default.jpg')); ?>"></img>
                  <?php endif; ?>
                </td> -->
                <td><?php echo e(ucfirst($row->f_name)); ?> <?php echo e(ucfirst($row->m_name)); ?> <?php echo e(ucfirst($row->l_name)); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->mobile); ?></td>
               <!--  <td><a href="<?php echo e(url('member/status/' . base64_encode($row->cust_id))); ?>" title="Change Status"><?php echo e($row->status == 1 ? 'Active' : 'In-Active'); ?></a></td>
-->
                <td> 
                    <a href="<?php echo e(url('member/edit/' . base64_encode($row->cust_id))); ?>" class=""><i class="fa fa-pencil" aria-hidden="true" title="Edit template"></i></a>&nbsp;&nbsp;
                    <a href="<?php echo e(url('member/delete/'. $row->cust_id)); ?>" class="" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash-o" aria-hidden="true" title="Delete Customer"></i></a></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </tbody>
          </table>

          </div><!-- table-responsive -->
        </div><!-- col-md-6 -->

        
      </div>
        
    </div><!-- contentpanel -->
    
  </div><!-- mainpanel -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
  jQuery(document).ready(function() {
    
    jQuery('#table1').dataTable();
    
    jQuery('#table2').dataTable({
      "sPaginationType": "full_numbers"
    });


    // Chosen Select
    jQuery("select").chosen({
      'min-width': '100px',
      'white-space': 'nowrap',
      disable_search_threshold: 10
    });
    
    // Delete row in a table
    jQuery('.delete-row').click(function(){
      var c = confirm("Continue delete?");
      if(c)
        jQuery(this).closest('tr').fadeOut(function(){
          jQuery(this).remove();
        });
        
        return false;
    });
    
    // Show aciton upon row hover
    jQuery('.table-hidaction tbody tr').hover(function(){
      jQuery(this).find('.table-action-hide a').animate({opacity: 1});
    },function(){
      jQuery(this).find('.table-action-hide a').animate({opacity: 0});
    });
  
  
  });
  $(function() {

  $('input[name="datefilter"]').daterangepicker({
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      }
  });

  $('input[name="datefilter"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  });

  $('input[name="datefilter"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });

});

</script>

<script type="text/javascript">
  
function filter_call(i)
      {
         
            $.ajax({
              type:"POST",
              url:" <?php echo e(url('customers/filterCall')); ?> ",
              data:{id:i,_token:"<?php echo e(Session::token()); ?>" },
              success: function (response) 
              {
                 
                   console.log(response);
        
                    var arr=response;
                    var len=arr.length;
                    var str='';
          
                    for(var i=0;i<len;i++)
                {
                  var j = i+1;
                  var user_id = arr[i].tr_id;
                  var encoded_value = btoa(user_id);
                  var redirect_url_details = '<?php echo url('customers/details/.')?>'  +encoded_value ;

                  var redirect_url_edit = '<?php echo url('customers/edit/.')?>'  +encoded_value ;
                  var redirect_url_delete = '<?php echo url('customers/delete/.')?>' +encoded_value;
                  var redirect_url_status = '<?php echo url('trainers/status/.')?>' +encoded_value;
                  var status = arr[i].status == 1 ? 'Active' : 'In-Active';
                 str=str+"<tr><td>"+arr[i].cust_name+"</td><td>"+arr[i].cust_email+"</td><td>"+arr[i].cust_mobile+"</td><td>"+arr[i].address+"</td><td><a href="+redirect_url_status+" class=''>"+status+"</td><td><a href="+redirect_url_details+" class=''><i class='fa fa-eye' aria-hidden='true' title='Click to view details'></i></a>&nbsp;&nbsp;<a href="+redirect_url_edit+" class=''> <i class='fa fa-pencil' aria-hidden='true' title='Edit template'></i></a>&nbsp;&nbsp;<a href="+redirect_url_delete+" class='' onclick='return confirm('Are you sure to delete?')><i class='fa fa-trash-o' aria-hidden='true' title='Delete Customer'></i></a></td></tr>";
              
               }

            var table = $('.tableid').DataTable();
            table.destroy();
            $("#tbody_tableid").html("");
            $("#tbody_tableid").append(str);
            var table = $('.tableid').DataTable( {
            responsive: true,
            paging: true,
            searching: true,
            "sPaginationType": "full_numbers"
            } );
            jQuery("select").chosen({
              'min-width': '100px',
              'white-space': 'nowrap',
              disable_search_threshold: 10
            });


              },
              error: function (xhr) {
              }
                
              
          });



        

          
      }

</script>