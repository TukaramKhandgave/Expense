<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="pageheader">
      <style type="text/css">
        .text-red{
          color: red;
        }
      </style>
    </div>
 <div class="contentpanel">

          <form id="form1" class="form-horizontal form-bordered" name="frm_submit_word" method="post" action="<?php echo e(url('member/insert')); ?> " enctype="multipart/form-data" >
            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title">Add a new Student</h4>
        </div>
        
        <div class="panel-body panel-body-nopadding">
            
            <div class="form-group">
              <label class="col-sm-3 control-label">First Name<span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="First Name" id="first_name" name="first_name" class="form-control" value="<?php echo e(old('first_name')); ?>" />
               <?php if($errors->first('first_name')!=NULL): ?>
                <p class="text-red"><?php echo e($errors->first('first_name')); ?></p>
                <?php endif; ?>
              </div>
               
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Middle Name</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Middle name" id="middle_name" name="middle_name" class="form-control"  value="<?php echo e(old('middle_name')); ?>" />
               
              </div>
              
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Last Name<span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Last name" id=last_name" name="last_name" class="form-control" value="<?php echo e(old('last_name')); ?>"/>
                <?php if($errors->first('last_name')!=NULL): ?>
                 <p class="text-red"><?php echo e($errors->first('last_name')); ?></p>
                <?php endif; ?>
              </div>
              
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Email<span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Email" id="email" name="email" class="form-control"value="<?php echo e(old('email')); ?>" />
               <?php if($errors->first('email')!=NULL): ?>
                <p class="text-red"><?php echo e($errors->first('email')); ?></p>
              <?php endif; ?>
              </div>
             
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Mobile<span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <input type="text" placeholder="Mobile" id="mobile" name="mobile" class="form-control" value="<?php echo e(old('mobile')); ?>"/>
                <?php if($errors->first('mobile')!=NULL): ?>
                <p class="text-red"><?php echo e($errors->first('mobile')); ?></p>
              <?php endif; ?>
              </div>
              
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Cast</label>
              <div class="col-sm-6">
               <select class="form-control" name="cast" id="cast" >
                    <option value="">Select Class</option>
                    <?php $__currentLoopData = $cast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($cas->cast_id); ?>"><?php echo e($cas->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Address<span class="asterisk">*</span></label>
              <div class="col-sm-6">
                <textarea class="form-control" placeholder="Address" name="address" id="address" rows="5"><?php echo e(old('address')); ?></textarea>
                 <?php if($errors->first('address')!=NULL): ?>
               <p class="text-red"><?php echo e($errors->first('address')); ?></p>
              <?php endif; ?>
              </div>
             
            </div>
            <div class="form-group">
              <label class="col-sm-3 control-label">Class</label>
              <div class="col-sm-6">
               <select class="form-control" name="class_name" id="class_name" >
                    <option value="">Select Class</option>
                    <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <option value="<?php echo e($c->class_id); ?>"><?php echo e($c->class_name); ?> (<?php echo e($c->year); ?>) <?php echo e($c->cem_name); ?> Sem</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Date of Birth</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Date of Birth" id="date_of_birth" name="date_of_birth" class="form-control" readonly="" value="<?php echo e(old('date_of_birth')); ?>" />
              </div>
            </div> 
            <div class="form-group">
              <label class="col-sm-3 control-label">Gender</label>
              <div class="col-sm-6">
                  <input type="radio" name="gender" value="1" checked> Male<br>
                  <input type="radio" name="gender" value="2" > Female<br>
              </div>
            </div> 
                       
           <div class="form-group">
              <label class="col-sm-3 control-label">Profile Image</label>
              <div class="col-sm-6">
                <input type="file" class="form-control" name="image" id="image" onchange="readURL(this);" />
              </div>
            </div> 
            <div class="form-group" id="preview_img" style="display: none;">
              <label class="col-sm-3 control-label">Preview Image</label>
              <div class="col-sm-6">
                <img id="preview" src="#" alt="your image" width="100px;" />
              </div>
            </div>

       </div>
        <!-- panel-body -->
        
        <div class="panel-footer">
          <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
              <button type="submit" class="btn btn-primary">Submit</button>
              &nbsp;
            </div>
          </div>
        </div>
        <!-- panel-footer --> 
        
      </div>
          </form>
         
    </div>
    
  </div><!-- mainpanel -->

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
    <script>
  jQuery(document).ready(function(){

  // Chosen Select
  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

});

      //CKEDITOR.replace( 'other' );
      CKEDITOR.replace( 'address' );

       function insertText(obj) {
                newtext = obj.value;
                console.log(newtext);
                CKEDITOR.instances['content'].insertText(newtext);

            }
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                  $("#preview_img").css("display", "block");
                    $('#preview').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }  
                  
          $('#date_of_birth,#join_date').datepicker({
            autoclose: true
          })

  
    </script>