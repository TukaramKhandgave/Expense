
   <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="pageheader">

    </div>
 <div class="contentpanel">
    <?php if($errors->any()): ?>
 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>    
          <form id="form1" class="form-horizontal" name="" method="post" action="<?php echo e(url('profile/update/'.$result->id)); ?>" >
            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
            <input type="hidden" name="u_id" id="u_id" value="<?php echo e($result->id); ?>" />
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">Manage Profile</h4>
              </div>
              <div class="panel-body">
              
                <div class="form-group">
                  <label class="col-sm-4 control-label">Name: <span class="asterisk">*</span></label>
                  <div class="col-sm-8">
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo e($result->name); ?>" />
                  </div>
                </div>
                
                <div class="form-group">
                  <label class="col-sm-4 control-label">Email: <span class="asterisk">*</span></label>
                  <div class="col-sm-8">
                     <input type="text" id="email" name="email" class="form-control" value="<?php echo e($result->email); ?>" />
                  </div>
                </div> 
                

                
                
              </div><!-- panel-body -->
              <div class="panel-footer">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary pull-left"> Back</a>
                <button class="btn btn-primary pull-right">Update</button>
              </div><!-- panel-footer -->
            </div><!-- panel-default -->
          </form>
         
    </div>
    
  </div><!-- mainpanel -->


  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
