<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fee extends Model
{
    public $timestamps=false;

	protected $fillable = [
        'member_id', 'cast','tue_fees','paid_tue_fees','remain_fees','semester','exam_fees','date','is_deleted','status',
    ];
}
