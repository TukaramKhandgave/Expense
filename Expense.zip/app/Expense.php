<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Expense extends Model
{
     public $timestamps=false;

	protected $fillable = [
        'exp_title', 'description','price','person_name','contact','date','is_deleted','status',
    ];
}
