<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    public $timestamps=false;

	protected $fillable = [
        'cust_id', 'm_name','l_name','email','mobile','birth_date','sex','join_date','address','subject','qualification','date','other','status',
    ];
}
