<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use DB;
use Session;


class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function profile(){ 
        $user = Auth::user(); //dd($user);

        $result = DB::table('users')->where('id',$user->id)->first();
        if($user == ''){
            return redirect('admin/login');
        }
        $result = DB::table('users')->where('id',$user->id)->first(); 
        return view('profile',compact('result'));
    }

    public function updateProfile(Request $request){
         $this->validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|',
            /*'mobile'=>'required',
            'address'=>'required',*/
        ]);
      
        DB::table('users')->where('id', $request->u_id)->update(['name' => $request->name,'email'=>$request->email]);

        return redirect('/')->with('message', 'success|Profile updated successfully!');
    }
    public function changePassword(){

        return view('change_password');
    }

    public function postPassword(Request $request){

        $user = Auth::user();
        $result = DB::table('users')->where('id',$user->id)->first();
        /*if (!($request->old_password) == (base64_decode($result->password))){
            return redirect('change_password')->withErrors("Your password doesn't match with the record. Please try again");
        }*/
       
        if($_POST['new_password'] != $_POST['confirm_password']){
            return redirect('change_password')->withErrors("New password doesn't match with the confirm password. Please try again"); 
        } 
        DB::table('users')->where('id', $result->id)->update(['password' => bcrypt($request->new_password)]);

        Session::flash('success_msg', 'Password updated successfully!');

        return redirect('change_password');
    }
}
