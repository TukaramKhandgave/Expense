<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Classes;
use Session;

class ClassController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $result = Classes::select('*')->get();
        return view('classes.index',compact('result'));
    }
    public function add(){
         
        return view('classes.add');
    }
    
    public function insert(Request $request){ //dd($request);
       
        $this->validate($request, [
            'class_name' => 'required',
            'cem_name' => 'required',
            'year' => 'required',
        ]);
       
        //insert word data
         $id = Classes::insert(['class_name'=>$request->class_name,'cem_name'=>$request->cem_name,'year'=>$request->year,'status'=>1]);
        
        Session::flash('success_msg', 'Class added successfully!');

        return redirect('classes');
    }      
    
    public function edit($id){ 
        $id = base64_decode($id);
        $result = Classes::select('*')->where('class_id',$id)->first(); 
        return view('classes.edit',compact('result'));
    }
public function update(Request $request){ 
    
      $this->validate($request, [
            'class_name' => 'required',
            'cem_name' => 'required',
            'year' => 'required',
        ]);
     
        Classes::where('class_id', $request->id)->update(['class_name'=>$request->class_name,'cem_name'=>$request->cem_name,'year'=>$request->year]);
        //store status message
        Session::flash('success_msg', 'Class Details updated successfully!');

        return redirect('classes');
    }
     public function delete($id){
         
        Classes::where('class_id', $id)->delete();
        Session::flash('success_msg', 'Class deleted successfully!');

        return redirect('classes');
    }
    public function status($id){ 
        $id = base64_decode($id);
        $result = Classes:: where('class_id',$id)->first();
        if(!empty($result)) {
            if($result->status == 1) $status = 0; else $status = 1;
               Classes::where('class_id',$id)->update(array('status' => $status));
               Session::flash('success_msg', 'Class Status changed successfully!');
               return redirect('classes');
         } else {
            return redirect('classes');
         }
    }
}
