<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\StaffSal;
use Session;
use Excel;

class StaffSalController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $result = StaffSal::select('*')->get();
        return view('staff_sal.index',compact('result'));
    }
    public function add(){
        return view('staff_sal.add');
    }
    
    public function insert(Request $request){ //dd($request);
       
        $this->validate($request, [
            'name' => 'required',
            'total_amount' => 'required',
        ]);
        
        //insert word data
         $id = StaffSal::insert(['name'=>$request->name,'designation'=>$request->designation,'mon_year'=>$request->mon_year,'day_of_month'=>$request->day_of_month,'leaves'=>$request->leaves,'work_day'=>$request->work_day,'total_amount'=>$request->total_amount,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0]);
        
        Session::flash('success_msg', 'Staff Salary added successfully!');

        return redirect('staff_sal');
    }      
    
    public function edit($id){ 
        $id = base64_decode($id);
       
        $result = StaffSal::select('*')->where('sal_id',$id)->first(); 
        return view('staff_sal.edit',compact('result'));
    }
public function update(Request $request){ 
    
//dd($request);
      $this->validate($request, [
            'name' => 'required',
            'total_amount' => 'required',
        ]);
      
        
        StaffSal::where('sal_id', $request->id)->update(['name'=>$request->name,'designation'=>$request->designation,'mon_year'=>$request->mon_year,'day_of_month'=>$request->day_of_month,'leaves'=>$request->leaves,'work_day'=>$request->work_day,'total_amount'=>$request->total_amount,'date'=>date('Y-m-d', strtotime($request->date))]);
        //store status message
        Session::flash('success_msg', 'Staff Salary Details updated successfully!');

        return redirect('staff_sal');
    }
      public function delete($id){
         
        StaffSal::where('sal_id', $id)->delete();
        Session::flash('success_msg', 'Staff Salary deleted successfully!');

        return redirect('staff_sal');
    }
    
    public function downloadExcel(){ 
    
        $result = StaffSal::select('*')->get();
        return Excel::create('salary', function($excel) use ($result) {
            $excel->sheet('mySheet', function($sheet) use ($result)
            {
                
                $sheet->cell('B2', function($cell) {$cell->setValue('*** Staff Salary ***');   });
                $sheet->cell('A5', function($cell) {$cell->setValue('Sr.No.');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('Name');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Designation');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Month-Year');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Day of Month');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Leaves');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Worked Day');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Amount');   });
                if (!empty($result)) {
                    $j= 1;
                    foreach ($result as $key => $value) {
                        $i= $key+6;
                        
                        $sheet->cell('A'.$i, $j); 
                        $sheet->cell('B'.$i, $value['name']); 
                        $sheet->cell('C'.$i, $value['designation']); 
                        $sheet->cell('D'.$i, $value['mon_year']); 
                        $sheet->cell('E'.$i, $value['day_of_month']); 
                        $sheet->cell('F'.$i, $value['leaves']); 
                        $sheet->cell('G'.$i, $value['work_day']); 
                        $sheet->cell('H'.$i, $value['total_amount']); 
                        $j++;
                    }
                }
            });
        })->download('xls');
        
    }
}
