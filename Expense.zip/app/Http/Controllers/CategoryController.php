<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use Session;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $result = Category::select('*')->get(); 
        return view('category.index',compact('result'));
    }
    public function add(){
         
        return view('category.add');
    }
    
    public function insert(Request $request){ //dd($request);
       
        $this->validate($request, [
            'category_type' => 'required',
            'category_name' => 'required',
        ]);
       	 $avail = Category::select('*')->where('category_name',$request->category_name)->first(); 
       	 if($avail){
       	 	Session::flash('success_msg', 'Category already exist!');
    		return redirect('category');
       	 }
        //insert word data
         $id = Category::insert(['cat_type'=>$request->category_type,'category_name'=>$request->category_name]);
        
        Session::flash('success_msg', 'Category added successfully!');

        return redirect('category');
    }      
    
    public function edit($id){ 
        $id = base64_decode($id);
        $result = Category::select('*')->where('cat_id',$id)->first(); 
        return view('category.edit',compact('result'));
    }
public function update(Request $request){ 
    
      $this->validate($request, [
            'category_type' => 'required',
            'category_name' => 'required',
        ]);
     	/*$avail = Category::select('*')->where('category_name',$request->category_name)->first(); 
       	 if($avail){
       	 	Session::flash('success_msg', 'Category already exist!');
    		return redirect('category');
       	 }*/
        Category::where('cat_id', $request->id)->update(['cat_type'=>$request->category_type,'category_name'=>$request->category_name]);
        //store status message
        Session::flash('success_msg', 'Category Details updated successfully!');

        return redirect('category');
    }
     public function delete($id){
         
        Category::where('cat_id', $id)->delete();
        Session::flash('success_msg', 'Category deleted successfully!');

        return redirect('category');
    }
    /*public function status($id){ 
        $id = base64_decode($id);
        $result = Category:: where('cat_id',$id)->first();
        if(!empty($result)) {
            if($result->status == 1) $status = 0; else $status = 1;
               Category::where('cat_id',$id)->update(array('status' => $status));
               Session::flash('success_msg', 'Category Status changed successfully!');
               return redirect('category');
         } else {
            return redirect('category');
         }
    }*/
}
