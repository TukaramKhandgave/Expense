<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Expense;
use App\Category;
use Session;
use Excel;
class ExpenseController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $expense = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.flag',2)->get(); 
        return view('expense.index',compact('expense'));
    }
    public function add(){
         $category = Category::where('cat_type',1)->get();
        return view('expense.add',compact('category'));
    }
    
    public function insert(Request $request){ //dd($request);
       
        $this->validate($request, [
            'category' => 'required',
            'perticular' => 'required',
            'amount' => 'required',
            'date' => 'required',
        ]);
       
        //insert word data
         $id = Expense::insert(['flag'=>2,'category'=>$request->category,'exp_title'=>$request->perticular,'description'=>$request->description,'price'=>$request->amount,'person_name'=>$request->person,'contact'=>$request->contact,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
        
        Session::flash('success_msg', 'Expense added successfully!');

        return redirect('expense');
    }      
    
    public function edit($id){  
        $id = base64_decode($id);
        $category = Category::where('cat_type',1)->get();
        $result = Expense::select('*')->where('exp_id',$id)->first(); 
        
        return view('expense.edit',compact('result','category'));
    }
public function update(Request $request){ 
    
      $this->validate($request, [
            'category' => 'required',
            'perticular' => 'required',
            'amount' => 'required',
            'date' => 'required',
        ]);
     
        Expense::where('exp_id', $request->exp_id)->update(['category'=>$request->category,'exp_title'=>$request->perticular,'description'=>$request->description,'price'=>$request->amount,'person_name'=>$request->person,'contact'=>$request->contact]);
        //store status message
        Session::flash('success_msg', 'Expense Details updated successfully!');

        return redirect('expense');
    }
     public function delete($id){
         
        Expense::where('exp_id', $id)->delete();
        Session::flash('success_msg', 'Expense deleted successfully!');

        return redirect('expense');
    }
   
    public function status($id){ 
        $id = base64_decode($id);
        $result = Expense:: where('exp_id',$id)->first();
        if(!empty($result)) {
            if($result->status == 1) $status = 0; else $status = 1;
               Expense::where('exp_id',$id)->update(array('status' => $status));
               Session::flash('success_msg', 'Expense Status changed successfully!');
               return redirect('expense');
         } else {
            return redirect('expense');
         }
    }
    public function downloadExcel(Request $request){ 

         if($request->datefilter){ 
            $date = explode("-",$request->datefilter);
            $start_date = date('Y-m-d', strtotime(trim($date[0]))); 
            $end_date = date('Y-m-d', strtotime(trim($date[1])));
           $result = Expense::join('category','category.cat_id','=','expenses.category')->where('date','>=',$start_date)->where('date','<=',$end_date)->where('expenses.flag',2)->get();

            /*$result = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.date','>=',$start_date)->where('expenses.date','<=',$end_date)->where('expenses.flag',1)->get();*/
        
        }else{

        $result = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.flag',2)->get();
       }
        return Excel::create('invoice', function($excel) use ($result) {
            $excel->sheet('mySheet', function($sheet) use ($result)
            {
               
                $sheet->cell('B2', function($mergeCells) {$mergeCells->setValue('***  Expense Records Management ***');   });
                $sheet->cell('A5', function($cell) {$cell->setValue('Sr.No.');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('Category');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Expense Title');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Discription');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Date');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Persion Name');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Contact');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Total Amount');   });
                
                if (!empty($result)) {
                    $j= 1;
                    $total=0;
                    $k=0;
                    foreach ($result as $key => $value) {
                        $i= $key+6;
                        
                        
                        $sheet->cell('A'.$i, $j); 
                        $sheet->cell('B'.$i, $value['category_name']); 
                        $sheet->cell('C'.$i, $value['exp_title']); 
                        $sheet->cell('D'.$i, strip_tags($value['description'])); 
                        $sheet->cell('E'.$i, $value['date']); 
                        $sheet->cell('F'.$i, $value['person_name']); 
                        $sheet->cell('G'.$i, $value['contact']); 
                        $sheet->cell('H'.$i, $value['price']); 
                        $j++;
                         $total =  $total + $value['price'];
                         $k=$i+2;
                    }
                     $sheet->cell('G'.$k,"Total Expense" );
                     $sheet->cell('H'.$k,$total );
                }
            });
        })->download('xls');
        
    }
}
