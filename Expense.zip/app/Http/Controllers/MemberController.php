<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Member;
use App\Classes;
use App\Cast;
use Session;
use Excel;

class MemberController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        //$this->middleware('super');
    }
    public function index(){
        $result = Member::select('*')->get();
        return view('member.index',compact('result'));
    }
    public function add(){
         $class = Classes::where('status',1)->get();
         $cast = Cast::get();
        return view('member.add',compact('class','cast'));
    }
    
    public function insert(Request $request){ //dd($request);
       
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'mobile' => 'required',
            'address' => 'required',
        ]);
        if($file=$request->file('image'))
        {
            $img_name=date('d-m-Y-H-i-s').'-'.$file->getClientOriginalName(); 
            $file->move(public_path().'/profile_images/',$img_name);
        }else{
            $img_name ='';
        }
        //insert word data
         $id = Member::insert(['f_name'=>$request->first_name,'m_name'=>$request->middle_name,'l_name'=>$request->last_name,'email'=>$request->email,'mobile'=>$request->mobile,'cast'=>$request->cast,'birth_date'=>date('Y-m-d', strtotime($request->date_of_birth)),'sex'=>$request->gender,'class'=>$request->class_name,'address'=>$request->address,'date'=>date('Y-m-d'),'image'=>$img_name,'status'=>1]);
        
        Session::flash('success_msg', 'Member added successfully!');

        return redirect('member');
    }      
    
    public function edit($id){ 
        $id = base64_decode($id);
        $class = Classes::where('status',1)->get();
        $cast = Cast::get();
        $result = Member::select('*')->where('cust_id',$id)->first(); 
        return view('member.edit',compact('result','class','cast'));
    }
public function update(Request $request){ 
    
//dd($request);
      $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'mobile' => 'required',
            'address' => 'required',
        ]);
      if($file=$request->file('image'))
        {
            $img_name=date('d-m-Y-H-i-s').'-'.$file->getClientOriginalName(); 
            $file->move(public_path().'/profile_images/',$img_name);

            $result = Member::where('cust_id', $request->id)->first();
            if($result->image)
            {
                $filepath =public_path().'/profile_images/'.$result->image;
                unlink($filepath);
            }
            Member::where('cust_id', $request->id)->update(['image'=>$img_name]);
        }
        //dd(date('Y-m-d', strtotime($request->birth_date)));
        //update template data
        Member::where('cust_id', $request->id)->update(['f_name'=>$request->first_name,'m_name'=>$request->middle_name,'l_name'=>$request->last_name,'email'=>$request->email,'mobile'=>$request->mobile,'cast'=>$request->cast,'birth_date'=>date('Y-m-d', strtotime($request->birth_date)),'class'=>$request->class_name,'sex'=>$request->gender,'address'=>$request->address]);
        //store status message
        Session::flash('success_msg', 'Member Details updated successfully!');

        return redirect('member');
    }
     public function delete($id){
         $result = Member::where('cust_id', $id)->first();
       if($result->img){
            $filepath =public_path().'/profile_images/'.$img;
            unlink($filepath);
           }
        Member::where('cust_id', $id)->delete();
        Session::flash('success_msg', 'Member deleted successfully!');

        return redirect('member');
    }
    public function status($id){ 
        $id = base64_decode($id);
        $result = Member:: where('cust_id',$id)->first();
        if(!empty($result)) {
            if($result->status == 1) $status = 0; else $status = 1;
               Member::where('cust_id',$id)->update(array('status' => $status));
               Session::flash('success_msg', 'Member Status changed successfully!');
               return redirect('member');
         } else {
            return redirect('member');
         }
    }
    public function downloadExcel(Request $request){ 
        
         if($request->datefilter){ 
            $date = explode("-",$request->datefilter);
            $start_date = date('Y-m-d', strtotime(trim($date[0]))); 
            $end_date = date('Y-m-d', strtotime(trim($date[1])));
            //SELECT * FROM `expenses` INNER JOIN category ON expenses.category=category.cat_id WHERE expenses.flag=1 AND expenses.date >= '2002-01-01' AND expenses.date <= '2002-01-20' 
            $result = $result = Member::join('classes','members.class','=','classes.class_id')->join('casts','members.cast','=','casts.cast_id')->where('members.date','>=',$start_date)->where('members.date','<=',$end_date)->get();
           /*  Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.date','>=',$start_date)->where('expenses.date','<=',$end_date)->where('expenses.flag',1)->get();*/
        
        }else{
           $result = Member::join('classes','members.class','=','classes.class_id')->join('casts','members.cast','=','casts.cast_id')->get();
        }

        
        return Excel::create('invoice', function($excel) use ($result) {
            $excel->sheet('mySheet', function($sheet) use ($result)
            {
                
                $sheet->cell('B2', function($cell) {$cell->setValue('***  Student Records ***');   });
                $sheet->cell('A5', function($cell) {$cell->setValue('Sr.No.');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('Student Name');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Email');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Mobile');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Birth Date');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Gender');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Cast');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Class');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('Address');   });
                if (!empty($result)) {
                    $j= 1;
                    foreach ($result as $key => $value) {
                        $i= $key+6;
                        
                        if($value['sex'] == 1){
                            $gender = "Male";
                        }else{
                             $gender = "Female";
                        }
                        $sheet->cell('A'.$i, $j); 
                        $sheet->cell('B'.$i, $value['f_name'].' '.$value['m_name'].' '.$value['l_name']); 
                        $sheet->cell('C'.$i, $value['email']); 
                        $sheet->cell('D'.$i, $value['mobile']); 
                        $sheet->cell('E'.$i, $value['birth_date']); 
                        $sheet->cell('F'.$i, $gender); 
                        $sheet->cell('G'.$i, $value['title']); 
                        $sheet->cell('H'.$i, $value['class_name']); 
                        $sheet->cell('I'.$i, strip_tags($value['address'])); 
                        $j++;
                    }
                }
            });
        })->download('xls');
        
    }
}
