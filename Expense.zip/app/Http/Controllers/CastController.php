<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cast;
use App\Category;
use Session;

class CastController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $result = Cast::get(); 
        return view('cast.index',compact('result'));
    }
    public function add(){
        return view('cast.add');
    }
    
    public function insert(Request $request){ //dd($request);
       
        $this->validate($request, [
            'title' => 'required',
            'fees' => 'required',
        ]);
       	 
        //insert word data
         $id = Cast::insert(['title'=>$request->title,'fees'=>$request->fees]);
        
        Session::flash('success_msg', 'Cast added successfully!');

        return redirect('cast');
    }      
    
    public function edit($id){ 
        $id = base64_decode($id);
        $result = Cast::select('*')->where('cast_id',$id)->first(); 
        return view('cast.edit',compact('result'));
    }
public function update(Request $request){ 
    
      $this->validate($request, [
            'title' => 'required',
            'fees' => 'required',
        ]);
     	
        Cast::where('cast_id', $request->id)->update(['title'=>$request->title,'fees'=>$request->fees]);
        //store status message
        Session::flash('success_msg', 'Cast Details updated successfully!');

        return redirect('cast');
    }
     public function delete($id){
         
        Cast::where('cast_id', $id)->delete();
        Session::flash('success_msg', 'Cast deleted successfully!');

        return redirect('cast');
    }
}
