<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Fee;
use App\Member;
use App\Category;
use App\Expense;
use Session;
use Excel;

Class FeeController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){

    
        //$expense = Expense::select('*')->where('flag',2)->get(); 
        $income = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.flag',1)->get();  //dd($income);
        return view('fees.index',compact('income'));
    }
    public function add(){
        $category = Category::where('cat_type',2)->get();
        $members = Member::get();
        return view('fees.add',compact('members','category'));
    }
    
    public function insert(Request $request){ 
       
        $this->validate($request, [
            'category' => 'required',
            'date' => 'required',
        ]);
        
        if($request->cat_type == 2){
           if($request->fees_type == 1){
            $this->validate($request, [
                'exam_fee' => 'required',
                'student_name' => 'required',
                'fees_type' => 'required',
            ]);
           
             $id = Expense::insert(['flag'=>1,'category'=>$request->category,'stud_id'=>$request->stud_id,'student_name'=>$request->full_name,'cast'=>$request->cast,'income_amount'=>$request->exam_fee,'fees_type'=>$request->fees_type,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
             Session::flash('success_msg', 'Income added successfully!');
             return redirect('fees');
            
           }elseif ($request->fees_type==2) {
            $this->validate($request, [
                'student_name' => 'required',
                'fees_type' => 'required',
                'paid_fee' => 'required',
            ]);
             
             $id = Expense::insert(['flag'=>1,'category'=>$request->category,'stud_id'=>$request->stud_id,'student_name'=>$request->full_name,'cast'=>$request->cast,'total_fees'=>$request->total_fee,'income_amount'=>$request->paid_fee,'fees_type'=>$request->fees_type,'remain_fees'=>$request->remain_fee,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
             Session::flash('success_msg', 'Income added successfully!');
             return redirect('fees');
           }else{
             $this->validate($request, [
                'student_name' => 'required',
                'fees_type' => 'required',
                'other_title' => 'required',
                'other_fees' => 'required',
            ]);
             
             $id = Expense::insert(['flag'=>1,'category'=>$request->category,'stud_id'=>$request->stud_id,'student_name'=>$request->full_name,'cast'=>$request->cast,'other_fees_title'=>$request->other_title,'income_amount'=>$request->other_fees,'fees_type'=>$request->fees_type,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
             Session::flash('success_msg', 'Income added successfully!');
             return redirect('fees');
           }
        }else{
             $this->validate($request, [
                'perticular' => 'required',
                'amount' => 'required',
            ]);
              $id = Expense::insert(['flag'=>1,'category'=>$request->category,'exp_title'=>$request->perticular,'description'=>$request->description,'income_amount'=>$request->amount,'person_name'=>$request->person,'contact'=>$request->contact,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
        
             Session::flash('success_msg', 'Income added successfully!');
             return redirect('fees');
        }
        
    }      
    
    public function edit($id){  
        $id = base64_decode($id); //dd($id);
        $category = Category::where('cat_type',2)->get();
        $members = Member::get();
        $result = Expense::select('*')
        ->join('category','category.cat_id','=','expenses.category')
        ->where('expenses.exp_id',$id)->first(); 

        return view('fees.edit',compact('result','members','category'));
    }
public function update(Request $request){  
    
      $this->validate($request, [
            'category' => 'required',
            'date' => 'required',
        ]);
     
       if($request->cat_type == 2){
           if($request->fees_type == 1){
            $this->validate($request, [
                'exam_fee' => 'required',
                'student_name' => 'required',
                'fees_type' => 'required',
            ]);
           
             $id = Expense::where('exp_id',$request->exp_id)->update(['flag'=>1,'category'=>$request->category,'stud_id'=>$request->stud_id,'student_name'=>$request->full_name,'cast'=>$request->cast,'income_amount'=>$request->exam_fee,'fees_type'=>$request->fees_type,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
             Session::flash('success_msg', 'Income updated successfully!');
             return redirect('fees');
            
           }elseif ($request->fees_type==2) {
            $this->validate($request, [
                'student_name' => 'required',
                'fees_type' => 'required',
                'paid_fee' => 'required',
            ]);
             
             $id = Expense::where('exp_id',$request->exp_id)->update(['flag'=>1,'category'=>$request->category,'stud_id'=>$request->stud_id,'student_name'=>$request->full_name,'cast'=>$request->cast,'total_fees'=>$request->total_fee,'income_amount'=>$request->paid_fee,'fees_type'=>$request->fees_type,'remain_fees'=>$request->remain_fee,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
             Session::flash('success_msg', 'Income updated successfully!');
             return redirect('fees');
           }else{
             $this->validate($request, [
                'student_name' => 'required',
                'fees_type' => 'required',
                'other_title' => 'required',
                'other_fees' => 'required',
            ]);
             
             $id = Expense::where('exp_id',$request->exp_id)->update(['flag'=>1,'category'=>$request->category,'stud_id'=>$request->stud_id,'student_name'=>$request->full_name,'cast'=>$request->cast,'other_fees_title'=>$request->other_title,'income_amount'=>$request->other_fees,'fees_type'=>$request->fees_type,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
             Session::flash('success_msg', 'Income updated successfully!');
             return redirect('fees');
           }
        }else{
             $this->validate($request, [
                'perticular' => 'required',
                'amount' => 'required',
            ]);
              $id = Expense::where('exp_id',$request->exp_id)->update(['flag'=>1,'category'=>$request->category,'exp_title'=>$request->perticular,'description'=>$request->description,'income_amount'=>$request->amount,'person_name'=>$request->person,'contact'=>$request->contact,'date'=>date('Y-m-d', strtotime($request->date)),'is_deleted'=>0,'status'=>1]);
        
             Session::flash('success_msg', 'Income updated successfully!');
             return redirect('fees');
        }
    }
     public function delete($id){
         
        Expense::where('exp_id', $id)->delete();
        Session::flash('success_msg', 'Record deleted successfully!');

        return redirect('fees');
    }
    public function getCastAction(Request $request){
         
       $student = Member::join('casts','members.cast','=','casts.cast_id')->where('members.cust_id', $request->id)->first();
         return response()->json($student);
    }
    public function getCatTypeAction(Request $request){
         
       $category = Category::where('cat_id', $request->cat_id)->first();
         return response()->json($category);
    }
    public function status($id){ 
        $id = base64_decode($id);
        $result = Fee:: where('fees_id',$id)->first();
        if(!empty($result)) {
            if($result->status == 1) $status = 0; else $status = 1;
               Fee::where('fees_id',$id)->update(array('status' => $status));
               Session::flash('success_msg', 'Fees Status changed successfully!');
               return redirect('fees');
         } else {
            return redirect('fees');
         }
    }
    public function downloadExcel(Request $request){  
        

        if($request->datefilter){ 
            $date = explode("-",$request->datefilter);
            $start_date = date('Y-m-d', strtotime(trim($date[0]))); 
            $end_date = date('Y-m-d', strtotime(trim($date[1])));
            //SELECT * FROM `expenses` INNER JOIN category ON expenses.category=category.cat_id WHERE expenses.flag=1 AND expenses.date >= '2002-01-01' AND expenses.date <= '2002-01-20' 
            $result = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.date','>=',$start_date)->where('expenses.date','<=',$end_date)->where('expenses.flag',1)->get();
        
        }else{
            $result = Expense::select('*')->join('category','category.cat_id','=','expenses.category')->where('expenses.flag',1)->get();
        }
       
        return Excel::create('invoice', function($excel) use ($result) {
            $excel->sheet('mySheet', function($sheet) use ($result)
            {
                
                $sheet->cell('B2', function($cell) {$cell->setValue('***  Income Report ***');   });
                $sheet->cell('A5', function($cell) {$cell->setValue('Sr.No.');   });
                $sheet->cell('B5', function($cell) {$cell->setValue('Category');   });
                $sheet->cell('C5', function($cell) {$cell->setValue('Non-Fees Title');   });
                $sheet->cell('D5', function($cell) {$cell->setValue('Description');   });
                $sheet->cell('E5', function($cell) {$cell->setValue('Person Name');   });
                $sheet->cell('F5', function($cell) {$cell->setValue('Contact');   });
                $sheet->cell('G5', function($cell) {$cell->setValue('Student Name');   });
                $sheet->cell('H5', function($cell) {$cell->setValue('Fees Type');   });
                $sheet->cell('I5', function($cell) {$cell->setValue('Total Fee');   });
                $sheet->cell('J5', function($cell) {$cell->setValue('Remain Fee');   });
                $sheet->cell('K5', function($cell) {$cell->setValue('Date');   });
                $sheet->cell('L5', function($cell) {$cell->setValue('Amount');   });
 
                if (!empty($result)) {
                    $j= 1;
                    $total=0;
                    $k=0;
                    foreach ($result as $key => $value) {

                         if($value['fees_type']==1){
                           $fees =  "Exam Fees";
                          }elseif($value['fees_type']==2){
                            $fees =  "Tution Fees";
                          }else{
                            $fees = $value['other_fees_title'] ;
                          } 

                        $i= $key+6;
                                                
                        $sheet->cell('A'.$i, $j); 
                        $sheet->cell('B'.$i, $value['category_name']); 
                        $sheet->cell('C'.$i, $value['exp_title']); 
                        $sheet->cell('D'.$i, strip_tags($value['description'])); 
                        $sheet->cell('E'.$i, $value['person_name']); 
                        $sheet->cell('F'.$i, $value['contact']); 
                        $sheet->cell('G'.$i, $value['student_name']); 
                        $sheet->cell('H'.$i, $fees); 
                        $sheet->cell('I'.$i, $value['total_fees']); 
                        $sheet->cell('J'.$i, $value['remain_fees']); 
                        $sheet->cell('K'.$i, $value['date']); 
                        $sheet->cell('L'.$i,  $value['income_amount']); 
                        $j++;
                         $total =  $total + $value['income_amount'];
                         $k=$i+2;
                    }
                    //dd($total);
               
                 $sheet->cell('K'.$k,"Total Income" );
                 $sheet->cell('L'.$k,$total );
                }
            });
        })->download('xls');
        
    }
}
