<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Member;
use App\Expense;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard');
    }
     public function getDashboard()
    {
        $result = Member::select('*')->count();
        $result1 = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.flag',1)->count();
        $result2 = Expense::join('category','category.cat_id','=','expenses.category')->where('expenses.flag',2)->count();
       
        return view('dashboard',compact('result','result1','result2'));
    }
}
